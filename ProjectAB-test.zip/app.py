import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from statsmodels.stats.proportion import proportions_ztest

st.set_page_config(page_title="Checkout A/B Dashboard", layout="wide")

@st.cache_data
def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    # Нормализация типов/значений
    for col in ["added_to_cart", "reached_checkout", "paid"]:
        if col in df.columns:
            df[col] = df[col].astype(int)
    return df

def apply_filters(df: pd.DataFrame, device: str, country: str, group: str) -> pd.DataFrame:
    out = df.copy()
    if device != "All":
        out = out[out["device"] == device]
    if country != "All":
        out = out[out["country"] == country]
    if group != "All":
        out = out[out["group"] == group]
    return out

def kpi_by_group(df: pd.DataFrame) -> pd.DataFrame:
    # KPI на user-level
    res = (
        df.groupby("group", as_index=False)
          .agg(
              users=("user_id", "count"),
              paid_users=("paid", "sum"),
              conversion=("paid", "mean"),
              arpu=("revenue", "mean"),
              avg_time_to_pay=("time_to_pay", "mean"),
          )
          .sort_values("group")
    )
    return res

def ztest_conversion(kpi: pd.DataFrame):
    # (z, p) или (None, None) если данных недостаточно
    if set(kpi["group"]) >= {"A", "B"}:
        a = kpi.set_index("group").loc["A"]
        b = kpi.set_index("group").loc["B"]
        successes = np.array([a["paid_users"], b["paid_users"]], dtype=float)
        nobs = np.array([a["users"], b["users"]], dtype=float)
        if np.all(nobs > 0):
            z, p = proportions_ztest(successes, nobs)
            return float(z), float(p)
    return None, None

def uplift(kpi: pd.DataFrame):
    if set(kpi["group"]) >= {"A", "B"}:
        a = kpi.set_index("group").loc["A"]
        b = kpi.set_index("group").loc["B"]
        conv_a, conv_b = float(a["conversion"]), float(b["conversion"])
        uplift_abs = conv_b - conv_a
        uplift_rel = (uplift_abs / conv_a) if conv_a > 0 else np.nan
        return conv_a, conv_b, uplift_abs, uplift_rel
    return None, None, None, None

def funnel_table(df: pd.DataFrame) -> pd.DataFrame:
    # paid => reached_checkout => added_to_cart :contentReference[oaicite:1]{index=1}
    steps = [("added_to_cart", "Added to cart"),
             ("reached_checkout", "Reached checkout"),
             ("paid", "Paid")]
    out = []
    for g, part in df.groupby("group"):
        prev = None
        for col, label in steps:
            users = int(part[col].sum())
            rate = None if prev is None or prev == 0 else users / prev
            out.append({"group": g, "step": label, "users": users, "rate_from_prev": rate})
            prev = users
    return pd.DataFrame(out)

def device_segment(df: pd.DataFrame) -> pd.DataFrame:
    seg = (
        df.groupby(["group", "device"], as_index=False)
          .agg(users=("user_id", "count"),
               conversion=("paid", "mean"),
               arpu=("revenue", "mean"))
    )
    # uplift vs A внутри device
    a = seg[seg["group"] == "A"][["device", "conversion"]].rename(columns={"conversion": "conv_A"})
    seg = seg.merge(a, on="device", how="left")
    seg["uplift_abs_vs_A"] = np.where(seg["group"] == "B", seg["conversion"] - seg["conv_A"], np.nan)
    return seg

def fmt_pct(x):
    return "—" if x is None or (isinstance(x, float) and np.isnan(x)) else f"{x*100:.2f}%"

def fmt_pp(x):
    return "—" if x is None or (isinstance(x, float) and np.isnan(x)) else f"{x*100:.2f} п.п."

def fmt_money(x):
    return "—" if x is None or (isinstance(x, float) and np.isnan(x)) else f"{x:.2f}"

def fmt_time(x):
    return "—" if x is None or (isinstance(x, float) and np.isnan(x)) else f"{x:.1f} сек"

#  UI 
st.title("A/B Test Dashboard: Checkout Redesign")

with st.sidebar:
    st.header("Filters")
    data_path = st.text_input("CSV path", value="checkout_ab_test.csv")
    df = load_data(data_path)

    device_opt = ["All"] + sorted(df["device"].dropna().unique().tolist())
    country_opt = ["All"] + sorted(df["country"].dropna().unique().tolist())
    group_opt = ["All"] + sorted(df["group"].dropna().unique().tolist())

    device = st.selectbox("Device", device_opt, index=0)
    country = st.selectbox("Country", country_opt, index=0)
    group = st.selectbox("Group", group_opt, index=0)

dff = apply_filters(df, device, country, group)

# KPI layer
kpi = kpi_by_group(dff)
z, p = ztest_conversion(kpi)
conv_a, conv_b, uplift_abs, uplift_rel = uplift(kpi)

# TOP: KPI cards 
c1, c2, c3, c4, c5 = st.columns(5)

total_users = int(dff["user_id"].count())
paid_users = int(dff["paid"].sum())
overall_conv = dff["paid"].mean() if total_users else np.nan
overall_arpu = dff["revenue"].mean() if total_users else np.nan

with c1:
    st.metric("Users", f"{total_users:,}")
with c2:
    st.metric("Paid users", f"{paid_users:,}")
with c3:
    st.metric("Overall conversion", fmt_pct(overall_conv))
with c4:
    st.metric("Overall ARPU", fmt_money(overall_arpu))
with c5:
    if p is None:
        st.metric("p-value (z-test)", "—")
    else:
        st.metric("p-value (z-test)", f"{p:.3g}")

#  A vs B summary
st.subheader("A vs B summary")

colL, colR = st.columns([1, 1])

with colL:
    st.dataframe(
        kpi.assign(
            conversion=kpi["conversion"].map(lambda x: float(x)),
            arpu=kpi["arpu"].map(lambda x: float(x)),
            avg_time_to_pay=kpi["avg_time_to_pay"].map(lambda x: float(x)),
        ),
        use_container_width=True
    )

with colR:
    # KPI indicators
    fig = go.Figure()

    if conv_a is not None and conv_b is not None:
        fig.add_trace(go.Indicator(
            mode="number",
            value=conv_a * 100,
            title={"text": "Conversion A (%)"},
            domain={"row": 0, "column": 0},
        ))
        fig.add_trace(go.Indicator(
            mode="number",
            value=conv_b * 100,
            title={"text": "Conversion B (%)"},
            domain={"row": 0, "column": 1},
        ))
        fig.add_trace(go.Indicator(
            mode="number",
            value=uplift_abs * 100,
            title={"text": "Uplift (pp) B-A"},
            domain={"row": 1, "column": 0},
        ))
        fig.add_trace(go.Indicator(
            mode="number",
            value=uplift_rel * 100 if uplift_rel is not None else np.nan,
            title={"text": "Uplift (rel %)"},
            domain={"row": 1, "column": 1},
        ))

    fig.update_layout(
        grid={"rows": 2, "columns": 2, "pattern": "independent"},
        height=280,
        margin=dict(l=10, r=10, t=10, b=10)
    )
    st.plotly_chart(fig, use_container_width=True)

# Recommendation (простое правило)
if p is not None and uplift_abs is not None:
    rec = "Rollout" if (p < 0.05 and uplift_abs > 0) else "Hold / Investigate"
    st.info(f"Recommendation: **{rec}**")

# ---------- Funnel ----------
st.subheader("Checkout funnel")
funnel = funnel_table(dff)

fig_funnel = px.bar(
    funnel,
    x="step",
    y="users",
    color="group",
    barmode="group",
    title="Users by funnel step",
)
st.plotly_chart(fig_funnel, use_container_width=True)

#  Device segment
st.subheader("Segment analysis: Device")
seg = device_segment(dff)

fig_seg = px.bar(
    seg,
    x="device",
    y="conversion",
    color="group",
    barmode="group",
    title="Conversion by device and group",
)
fig_seg.update_yaxes(tickformat=".1%")
st.plotly_chart(fig_seg, use_container_width=True)

# Табличка uplift по device
seg_uplift = seg[seg["group"] == "B"][["device", "uplift_abs_vs_A"]].copy()
seg_uplift["uplift_pp"] = seg_uplift["uplift_abs_vs_A"] * 100
st.dataframe(seg_uplift[["device", "uplift_pp"]], use_container_width=True)

# Distributions 
st.subheader("Distributions (Paid users)")
paid_df = dff[dff["paid"] == 1].copy()

if len(paid_df) > 0:
    col1, col2 = st.columns(2)
    with col1:
        fig_time = px.violin(
            paid_df,
            x="group",
            y="time_to_pay",
            box=True,
            points="outliers",
            title="Time to pay distribution (sec)",
        )
        st.plotly_chart(fig_time, use_container_width=True)
    with col2:
        fig_rev = px.violin(
            paid_df,
            x="group",
            y="revenue",
            box=True,
            points="outliers",
            title="Revenue distribution",
        )
        st.plotly_chart(fig_rev, use_container_width=True)
else:
    st.warning("No paid users for current filters — distributions are empty.")

st.caption("Data: synthetic e-commerce events (A/B checkout).")
