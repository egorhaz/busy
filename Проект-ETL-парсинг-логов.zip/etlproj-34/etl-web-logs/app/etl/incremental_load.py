import os
import sys
from pathlib import Path
import psycopg2


project_root = Path(__file__).resolve().parents[2]
venv_root = Path(sys.executable).resolve().parents[1]
pyspark_home = venv_root / "Lib" / "site-packages" / "pyspark"

os.environ["JAVA_HOME"] = r"C:\Program Files\Eclipse Adoptium\jdk-11.0.30.7-hotspot"
os.environ["SPARK_HOME"] = str(pyspark_home)
os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable
os.environ["PATH"] = (
    str(Path(os.environ["JAVA_HOME"]) / "bin")
    + os.pathsep
    + str(pyspark_home / "bin")
    + os.pathsep
    + os.environ.get("PATH", "")
)

from pyspark.sql import SparkSession
from transforms import transform_web_logs

PIPELINE_NAME = "web_logs_incremental"


def get_conn():
    return psycopg2.connect(
        host="127.0.0.1",
        dbname="etl_db",
        user="etl_user",
        password="etl_pass"
    )


def get_last_hwm():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "SELECT last_hwm FROM etl_metadata WHERE pipeline_name = %s",
        (PIPELINE_NAME,)
    )
    row = cur.fetchone()
    cur.close()
    conn.close()
    return row[0] if row else None


def upsert_hwm(new_hwm):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO etl_metadata (pipeline_name, last_hwm, updated_at)
        VALUES (%s, %s, NOW())
        ON CONFLICT (pipeline_name)
        DO UPDATE SET
            last_hwm = EXCLUDED.last_hwm,
            updated_at = NOW()
    """, (PIPELINE_NAME, new_hwm))
    conn.commit()
    cur.close()
    conn.close()


def run_incremental_load():
    jar_path = project_root / "jars" / "postgresql.jar"

    spark = (
        SparkSession.builder
        .appName("web_logs_incremental")
        .master("local[*]")
        .config("spark.jars", str(jar_path))
        .config("spark.driver.extraClassPath", str(jar_path))
        .config("spark.executor.extraClassPath", str(jar_path))
        .getOrCreate()
    )

    url = "jdbc:postgresql://127.0.0.1:5432/etl_db"
    props = {
        "user": "etl_user",
        "password": "etl_pass",
        "driver": "org.postgresql.Driver"
    }

    last_hwm = get_last_hwm()
    print(f"Last HWM: {last_hwm}")

    if last_hwm:
        query = f"""
        (
            SELECT *
            FROM raw_web_logs
            WHERE timestamp > '{last_hwm}'
        ) AS raw_web_logs_inc
        """
    else:
        query = "raw_web_logs"

    df = spark.read.jdbc(url=url, table=query, properties=props)

    source_count = df.count()
    print(f"New source rows: {source_count}")

    if source_count == 0:
        print("No new data")
        spark.stop()
        return

    df_transformed = transform_web_logs(df)
    transformed_count = df_transformed.count()
    print(f"Transformed new rows: {transformed_count}")

    df_transformed.write.jdbc(
        url=url,
        table="dm_web_logs",
        mode="append",
        properties=props
    )

    max_hwm = df.agg({"timestamp": "max"}).collect()[0][0]
    upsert_hwm(max_hwm)

    print(f"New HWM saved: {max_hwm}")
    print("Incremental load completed")
    spark.stop()


if __name__ == "__main__":
    run_incremental_load()