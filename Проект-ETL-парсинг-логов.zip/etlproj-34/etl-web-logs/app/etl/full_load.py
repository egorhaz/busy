import os
import sys
from pathlib import Path

project_root = Path(__file__).resolve().parents[2]
venv_root = Path(sys.executable).resolve().parents[1]
pyspark_home = venv_root / "Lib" / "site-packages" / "pyspark"

os.environ["JAVA_HOME"] = r"C:\Program Files\Eclipse Adoptium\jdk-11.0.30.7-hotspot"
os.environ["SPARK_HOME"] = str(pyspark_home)
os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable
os.environ["PATH"] = (
    str(Path(os.environ["JAVA_HOME"]) / "bin")
    + os.pathsep
    + str(pyspark_home / "bin")
    + os.pathsep
    + os.environ.get("PATH", "")
)

from pyspark.sql import SparkSession
from transforms import transform_web_logs


def run_full_load():
    jar_path = project_root / "jars" / "postgresql.jar"

    spark = (
        SparkSession.builder
        .appName("web_logs_etl")
        .master("local[*]")
        .config("spark.jars", str(jar_path))
        .config("spark.driver.extraClassPath", str(jar_path))
        .config("spark.executor.extraClassPath", str(jar_path))
        .getOrCreate()
    )

    url = "jdbc:postgresql://127.0.0.1:5432/etl_db"
    properties = {
        "user": "etl_user",
        "password": "etl_pass",
        "driver": "org.postgresql.Driver"
    }

    df = spark.read.jdbc(
        url=url,
        table="raw_web_logs",
        properties=properties
    )

    print(f"Source rows: {df.count()}")

    df_transformed = transform_web_logs(df)

    print(f"After transform: {df_transformed.count()}")

    df_transformed.write.jdbc(
        url=url,
        table="dm_web_logs",
        mode="overwrite",
        properties=properties
    )

    print("Full load completed")
    spark.stop()


if __name__ == "__main__":
    run_full_load()