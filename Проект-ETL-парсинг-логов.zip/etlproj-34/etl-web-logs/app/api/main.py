from fastapi import FastAPI
import subprocess
import sys
import uuid
from datetime import datetime

app = FastAPI(title="Web Logs ETL API")

tasks = {}


def run_script(script_path: str):
    result = subprocess.run(
        [sys.executable, script_path],
        capture_output=True,
        text=True,
        cwd=r"C:\etlproj\etl-web-logs"
    )
    return result


@app.post("/etl/full")
def run_full():
    task_id = str(uuid.uuid4())
    started_at = datetime.now().isoformat()

    tasks[task_id] = {
        "task_id": task_id,
        "task_type": "full",
        "status": "running",
        "started_at": started_at,
        "finished_at": None,
        "stdout": None,
        "stderr": None
    }

    result = run_script(r"app\etl\full_load.py")

    tasks[task_id]["finished_at"] = datetime.now().isoformat()
    tasks[task_id]["stdout"] = result.stdout
    tasks[task_id]["stderr"] = result.stderr
    tasks[task_id]["status"] = "success" if result.returncode == 0 else "failed"

    return tasks[task_id]


@app.post("/etl/incremental")
def run_incremental():
    task_id = str(uuid.uuid4())
    started_at = datetime.now().isoformat()

    tasks[task_id] = {
        "task_id": task_id,
        "task_type": "incremental",
        "status": "running",
        "started_at": started_at,
        "finished_at": None,
        "stdout": None,
        "stderr": None
    }

    result = run_script(r"app\etl\incremental_load.py")

    tasks[task_id]["finished_at"] = datetime.now().isoformat()
    tasks[task_id]["stdout"] = result.stdout
    tasks[task_id]["stderr"] = result.stderr
    tasks[task_id]["status"] = "success" if result.returncode == 0 else "failed"

    return tasks[task_id]


@app.get("/etl/status/{task_id}")
def get_status(task_id: str):
    return tasks.get(task_id, {"error": "Task not found"})


@app.get("/etl/history")
def get_history():
    return list(tasks.values())